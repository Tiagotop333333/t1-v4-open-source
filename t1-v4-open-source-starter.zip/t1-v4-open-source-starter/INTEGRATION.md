# Integration checklist — required before release

The V4 source supplied for this starter imports these symbols:

- From `ternario.improved`: `_decode_indices`, `_encode_indices`
- From `ternario.v3`: `_decode_scales_log`, `_decode_values_i8`, `_encode_scales_log`, `_encode_values_i8`, `_pack_bits`, `_unpack_bits`
- The author's tests also import `relative_error` from `ternario.quant`

Those modules were not included in the conversation excerpt, so they have **not** been recreated or guessed here. Bring over the real, tested versions from the author's repository.

Before making a public release:

- [ ] Add the real helper modules under `src/ternario/`.
- [ ] Verify every import and run a clean-environment smoke test.
- [ ] Check ownership and license compatibility of V3/inherited code.
- [ ] Validate inputs: `group > 0`, supported `side_bits`, valid fractions, finite input values, and empty arrays.
- [ ] Confirm whether outlier/residual index and value encodings are fully accounted for by the BPW function.
- [ ] Compare estimated BPW with actual serialized bytes, including metadata and scale ranges.
- [ ] Run the full test suite and record Python/NumPy versions, CPU, seeds, and exact command lines.
- [ ] Add a matched-rate comparison against V3 and other relevant baselines.
- [ ] Tag a version only after the repository is runnable from a fresh clone.
