# Security policy

This repository is an experimental numerical-computing prototype and is not intended for production use. No formal security support window is established yet. Please avoid submitting confidential model weights or sensitive data in public issues.

For a security-sensitive report, contact the repository maintainer privately once a contact address has been added here.
