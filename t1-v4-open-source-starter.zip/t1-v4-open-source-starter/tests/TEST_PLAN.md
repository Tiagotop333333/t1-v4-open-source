# Test plan to port from the working repository

The tests below are a plan, not claimed passing tests. They need the inherited `improved.py`, `v3.py`, and `quant.py` modules first.

- Round-trip: decoded tensor has the original shape and only finite values.
- Quality threshold: report error for fixed synthetic seeds and parameter settings.
- Rate-matched V3/V4: choose settings with matching measured BPW, then compare error.
- Sparsity: increasing `lam` should be measured for its effect on non-zero fraction, error, and BPW; do not assert a universal monotonic relationship without checking the implementation.
- All-zero inputs: decoding stays finite and produces zeros, including padding boundaries.
- Edge cases: `n=0`, `group <= 0`, non-finite inputs, `outlier_frac`/`residual_frac` outside `[0, 1)`, and unsupported `side_bits` should have explicit behavior.
- Serialization accounting: assert agreement between the documented estimate and measured stored bytes, within a defined accounting model.

## Correction to the pasted all-zero test

The original assertion used chained slices ending in `[:50]`, so it checked only 50 elements, not all 50,000 zero values. Prefer:

```python
assert np.allclose(dq.reshape(-1)[:50_000], 0.0, atol=1e-9)
```

Also note that `w[:50] = 0.0` zeroes 50 rows of a `(200, 1000)` tensor, i.e. 50,000 scalar weights. It does not create exactly 50 groups when the quantizer group size is 64.
