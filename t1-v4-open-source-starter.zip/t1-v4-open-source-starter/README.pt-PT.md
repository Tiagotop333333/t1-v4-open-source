# T1 v4 — Quantização ternária hierárquica

**Estado: protótipo experimental de investigação.** O T1 v4 explora cinco níveis de reconstrução por grupo: `{-α₁, -α₂, 0, +α₂, +α₁}`, com `α₂ < α₁`. A hipótese é trocar alguma densidade por uma reconstrução mais fina, escolhendo o compromisso entre distorção e custo de representação.

## Nota importante antes de publicar

O ficheiro `src/ternario/v4.py` depende de funções auxiliares dos módulos `ternario.improved` e `ternario.v3`. Esses ficheiros não estavam incluídos no material recebido para preparar este starter. É necessário adicioná-los — verificando as licenças e dependências — antes de o apresentar como pacote executável ou publicar uma versão estável. Ver [`INTEGRATION.md`](INTEGRATION.md).

## Resultados preliminares fornecidos pelo autor

| BPW estimado | Erro relativo reportado | Versão |
|---:|---:|:---|
| 1,90 | 29,8% | V3 |
| 2,02 | 28,8% | V3 |
| 2,48 | 25,4% | V4 |
| 3,00 | 18,6% | V4 |

Estes valores são resultados comunicados pelo autor e não foram reproduzidos independentemente. As linhas apresentadas não são pares à mesma taxa de bits; por si só, não demonstram uma vantagem a BPW igual. O protocolo para registar comparações rigorosas está em [`benchmarks/README.md`](benchmarks/README.md).

## Próximos passos

1. Integrar os módulos auxiliares V3 e confirmar compatibilidade das funções.
2. Corrigir/portar os testes e executá-los num ambiente limpo.
3. Comparar V3 e V4 a taxas efetivas iguais, com várias seeds.
4. Registar os bytes serializados reais, não apenas o BPW estimado.
5. Testar pesos reais de modelos e, quando relevante, métricas da tarefa final.
6. Substituir os marcadores de autor em `LICENSE` e `CITATION.cff` e confirmar que todo o código herdado pode ser redistribuído.

A documentação detalhada do algoritmo está em [`docs/algorithm.md`](docs/algorithm.md).
