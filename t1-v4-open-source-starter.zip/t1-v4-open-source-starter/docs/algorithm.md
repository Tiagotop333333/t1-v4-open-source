# T1 v4 algorithm note

## Motivation

A conventional ternary quantizer reconstructs each weight using zero or one signed non-zero magnitude. T1 v4 adds a second magnitude per group, yielding five reconstruction levels:

\[
\{-\alpha_1, -\alpha_2, 0, +\alpha_2, +\alpha_1\},\qquad 0 < \alpha_2 < \alpha_1.
\]

The hypothesis is that, at a fixed effective rate, a representation can benefit from retaining fewer weights while approximating retained weights with one of two magnitudes.

## Group search

For each group, the current implementation:

1. Computes the mean absolute weight magnitude.
2. Sweeps threshold multipliers from `_TAUS` and magnitude ratios from `_BETAS`.
3. Selects non-zero candidates by thresholding absolute values.
4. Alternates between assigning the two non-zero magnitudes and updating their group-wise means for three iterations.
5. Evaluates squared reconstruction error plus a sparsity penalty:

   \[
   J = \mathrm{SSE} + 2\lambda N_{nz}.
   \]

6. Keeps the lowest-cost candidate, encodes the two scales, and uses the quantized scales to form the initial reconstruction.

`lam` is a rate–distortion control parameter, but it is not by itself a guarantee that two configurations or algorithms use equal effective rates. Rate-matched comparisons need a sweep over `lam` and must measure the actual representation size.

## Coding model

The implementation stores:

- a non-zero bitmap: one bit for each padded weight;
- one sign bit per non-zero weight;
- one magnitude-selection bit per non-zero weight;
- two encoded scales per group;
- optional outlier indices/values and residual indices/values.

Ignoring padding, metadata, outliers, residuals, and scale encoding details, the bitmap plus non-zero symbols contribute approximately

\[
1 + 2\rho \quad \text{bits/weight},
\]

where \(\rho=N_{nz}/N\). Scale and side-channel costs must be added for the full rate.

## Outliers and residual corrections

As in the supplied V3 design, a small set of high-magnitude weights can be stored separately. Residual corrections are selected from the remaining reconstruction error. These mechanisms can improve error but add index and value storage; they must be held constant across baselines when comparing the quantizer itself.

## Implementation caveats

- The implementation uses grid-search heuristics; it does not establish a global optimum.
- The scales are quantized after candidate selection, so the chosen candidate may not minimize distortion after scale quantization.
- The BPW function is an implementation estimate and should be validated against serialized bytes, including container metadata.
- The inherited codec helpers are external to this starter and must be included to reproduce behavior.
