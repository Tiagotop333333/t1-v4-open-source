# Contributing

Thanks for your interest in T1 v4. This is an experimental research prototype.

Before opening a pull request:

- Describe the exact change and the behavior it is intended to improve.
- Include a reproducible test or benchmark when changing quantization, codec, or rate accounting.
- Use fixed seeds and report both distortion and effective rate.
- Do not compare results at different bit budgets without clearly labeling the comparison.
- Keep benchmark outputs and commands in the repository where practical.
- Do not submit model weights, datasets, or other artifacts unless their licenses permit redistribution.

Please do not present results as independently reproduced unless another person or clean environment has actually reproduced them.
