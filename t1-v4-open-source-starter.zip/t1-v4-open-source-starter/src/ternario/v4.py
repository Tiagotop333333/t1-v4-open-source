from __future__ import annotations

import numpy as np

from .improved import _decode_indices, _encode_indices
from .v3 import (
    _decode_scales_log,
    _decode_values_i8,
    _encode_scales_log,
    _encode_values_i8,
    _pack_bits,
    _unpack_bits,
)

_BETAS = (0.3, 0.4, 0.5, 0.62)
_TAUS = (0.35, 0.5, 0.65, 0.85, 1.1, 1.5, 2.0, 2.6)

def quantize_t1_v4(
    w: np.ndarray,
    group: int = 64,
    outlier_frac: float = 0.005,
    residual_frac: float = 0.01,
    lam: float = 0.0,
    side_bits: int = 8,
) -> dict:
    w = np.ascontiguousarray(w, dtype=np.float32)
    orig_shape = w.shape
    orig_flat = w.reshape(-1)
    n = orig_flat.size

    work_flat = orig_flat
    outliers = None
    if outlier_frac > 0:
        k0 = int(n * outlier_frac)
        if k0 > 0:
            idx0 = np.sort(np.argpartition(np.abs(orig_flat), -k0)[-k0:])
            outliers = {
                "index": _encode_indices(idx0),
                "value": (
                    _encode_values_i8(orig_flat[idx0])
                    if side_bits == 8
                    else orig_flat[idx0].astype(np.float16)
                ),
            }
            work_flat = orig_flat.copy()
            work_flat[idx0] = 0.0

    pad = (-n) % group
    work = work_flat if pad == 0 else np.concatenate(
        [work_flat, np.zeros(pad, np.float32)]
    )
    g = work.reshape(-1, group)
    abs_g = np.abs(g)

    mean_abs = np.maximum(abs_g.mean(axis=1, keepdims=True), 1e-12)
    ng = g.shape[0]
    best_cost = np.full(ng, np.inf)
    best_mag = np.zeros(g.shape, dtype=bool)  
    best_nz = np.zeros(g.shape, dtype=bool)
    best_a1 = np.zeros((ng, 1), dtype=np.float32)
    best_a2 = np.zeros((ng, 1), dtype=np.float32)

    for tau_c in _TAUS:
        tau = tau_c * mean_abs
        nz = abs_g > tau
        a1 = np.maximum(
            (abs_g * nz).sum(1, keepdims=True)
            / np.maximum(nz.sum(1, keepdims=True), 1),
            1e-12,
        )
        for beta in _BETAS:
            a2 = beta * a1
            for _ in range(3):  
                mag = nz & (abs_g > (a1 + a2) / 2.0)
                small = nz & ~mag
                n1 = mag.sum(1, keepdims=True)
                n0 = small.sum(1, keepdims=True)
                a1n = np.where(
                    n1 > 0,
                    (abs_g * mag).sum(1, keepdims=True) / np.maximum(n1, 1),
                    a1,
                )
                a2n = np.where(
                    n0 > 0,
                    (abs_g * small).sum(1, keepdims=True) / np.maximum(n0, 1),
                    a2,
                )
                swap = a2n > a1n  
                a1n, a2n = np.where(swap, a2n, a1n), np.where(swap, a1n, a2n)
                a1, a2 = a1n, a2n

            mag = nz & (abs_g > (a1 + a2) / 2.0)
            small = nz & ~mag
            res_l = g * mag - np.sign(g) * mag * a1
            res_s = g * small - np.sign(g) * small * a2
            sse = (
                (res_l**2).sum(1)
                + (res_s**2).sum(1)
                + (np.where(~nz, g, 0.0) ** 2).sum(1)
            )
            nz_count = nz.sum(1)
            cost = sse + lam * 2.0 * nz_count
            upd = cost < best_cost
            best_cost = np.where(upd, cost, best_cost)
            best_mag = np.where(upd[:, None], mag, best_mag)
            best_nz = np.where(upd[:, None], nz, best_nz)
            best_a1 = np.where(upd[:, None], a1, best_a1)
            best_a2 = np.where(upd[:, None], a2, best_a2)

    c1, rng1 = _encode_scales_log(best_a1.reshape(-1))
    c2, rng2 = _encode_scales_log(
        np.maximum(best_a2.reshape(-1), 1e-12)
    )
    a1q = _decode_scales_log(c1, rng1).reshape(-1, 1)
    a2q = _decode_scales_log(c2, rng2).reshape(-1, 1)

    nz_mask = best_nz.reshape(-1)
    signs = np.sign(g).reshape(-1)[nz_mask] < 0
    mags = best_mag.reshape(-1)[nz_mask]  

    a_pair = np.concatenate([a2q, a1q], axis=1)  
    qv = np.zeros(n + pad, dtype=np.float32)
    pos = np.flatnonzero(nz_mask)
    qv[pos] = (
        np.where(signs, -1.0, 1.0)
        * a_pair[pos // group, mags.astype(np.int64)]
    )
    dq = qv[:n]
    residual = None
    k = int(n * residual_frac)
    if k > 0:
        resid = orig_flat - dq
        if outliers is not None:
            resid = resid.copy()
            resid[_decode_indices(outliers["index"])] = 0.0
        k = min(k, int((resid != 0).sum()))
        if k > 0:
            idx = np.sort(np.argpartition(np.abs(resid), -k)[-k:])
            val = (
                _encode_values_i8(resid[idx])
                if side_bits == 8
                else resid[idx].astype(np.float16)
            )
            residual = {"index": _encode_indices(idx), "value": val}

    return {
        "mode": "t1v4",
        "shape": orig_shape,
        "n": n,
        "group": group,
        "lam": lam,
        "bitmap": _pack_bits(nz_mask),
        "signs": _pack_bits(signs),
        "mags": _pack_bits(mags),
        "nz_total": int(nz_mask.sum()),
        "scale1_codes": c1,
        "scale1_rng": rng1,
        "scale2_codes": c2,
        "scale2_rng": rng2,
        "outliers": outliers,
        "residual": residual,
        "side_bits": side_bits,
    }

def dequantize_t1_v4(q: dict) -> np.ndarray:
    n, group = q["n"], q["group"]
    n_padded = n + ((-n) % group)
    nz = _unpack_bits(q["bitmap"], n_padded)
    signs = _unpack_bits(q["signs"], q["nz_total"])
    mags = _unpack_bits(q["mags"], q["nz_total"])

    a1 = _decode_scales_log(q["scale1_codes"], q["scale1_rng"]).reshape(-1, 1)
    a2 = _decode_scales_log(q["scale2_codes"], q["scale2_rng"]).reshape(-1, 1)
    a_pair = np.concatenate([a2, a1], axis=1)  

    qv = np.zeros(n_padded, dtype=np.float32)
    pos = np.flatnonzero(nz)
    qv[pos] = (
        np.where(signs, -1.0, 1.0)
        * a_pair[pos // group, mags.astype(np.int64)]
    )
    flat = qv[:n]

    for side in ("outliers", "residual"):
        s = q.get(side)
        if s is None:
            continue
        idx = _decode_indices(s["index"])
        val = (
            _decode_values_i8(s["value"])
            if q.get("side_bits", 8) == 8
            else s["value"].astype(np.float32)
        )
        flat = flat.copy()
        if side == "outliers":
            flat[idx] = val
        else:
            flat[idx] += val
    return flat.reshape(q["shape"])

def bits_per_weight_t1_v4(q: dict) -> float:
    n, group = q["n"], q["group"]
    n_padded = n + ((-n) % group)
    bits = n_padded + q["nz_total"] * 2 + 16 * (n_padded // group)
    for side in ("outliers", "residual"):
        s = q.get(side)
        if s is None:
            continue
        enc = s["index"]
        vbits = 8 if isinstance(s["value"], dict) else 16
        bits += enc["deltas"].size * (16 if enc["mode"] == "u16" else 32)
        bits += (
            s["value"]["codes"].size * vbits
            if isinstance(s["value"], dict)
            else s["value"].size * vbits
        )
    return bits / n
