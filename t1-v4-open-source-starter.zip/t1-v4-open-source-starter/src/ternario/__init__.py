"""T1 hierarchical ternary quantization prototype.

The v4 module depends on shared codec helpers from the author's V3 codebase.
See INTEGRATION.md before attempting to import or publish this package.
"""
