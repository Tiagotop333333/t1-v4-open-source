#!/usr/bin/env python3
"""Run the supplied synthetic-weight sweep after integrating V3 helper modules.

Example:
    python benchmarks/run_synthetic_sweep.py --lams 0,1e-5,1e-4,1e-3,1e-2 \
        --seeds 0,1,2 --output benchmarks/local_sweep.csv

This script reports estimated BPW from each implementation. It does not claim
that those estimates equal real serialized file size.
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ternario.v3 import (  # noqa: E402
    bits_per_weight_t1_v3,
    dequantize_t1_v3,
    quantize_t1_v3,
)
from ternario.v4 import (  # noqa: E402
    bits_per_weight_t1_v4,
    dequantize_t1_v4,
    quantize_t1_v4,
)
from ternario.quant import relative_error  # noqa: E402


def make_weights(seed: int, n: int = 200_000) -> np.ndarray:
    if n <= 0 or n % 1000 != 0:
        raise ValueError("n must be a positive multiple of 1000")
    rng = np.random.default_rng(seed)
    weights = np.concatenate(
        [
            rng.normal(0, 0.02, int(n * 0.99)),
            rng.normal(0, 0.2, n - int(n * 0.99)),
        ]
    ).astype(np.float32)
    rng.shuffle(weights)
    return weights.reshape(-1, 1000)


def parse_csv_floats(value: str) -> list[float]:
    try:
        return [float(part.strip()) for part in value.split(",") if part.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated numbers") from exc


def parse_csv_ints(value: str) -> list[int]:
    try:
        return [int(part.strip()) for part in value.split(",") if part.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated integers") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n", type=int, default=200_000, help="number of scalar weights; multiple of 1000")
    parser.add_argument("--seeds", type=parse_csv_ints, default=[0], help="comma-separated seeds")
    parser.add_argument("--lams", type=parse_csv_floats, default=[0.0, 1e-5, 1e-4, 1e-3, 1e-2])
    parser.add_argument("--group", type=int, default=64)
    parser.add_argument("--outlier-frac", type=float, default=0.005)
    parser.add_argument("--residual-frac", type=float, default=0.01)
    parser.add_argument("--side-bits", type=int, choices=(8, 16), default=8)
    parser.add_argument("--output", type=Path, help="optional CSV output path")
    args = parser.parse_args()

    rows: list[dict[str, object]] = []
    for seed in args.seeds:
        weights = make_weights(seed, args.n)
        for lam in args.lams:
            common = {
                "group": args.group,
                "outlier_frac": args.outlier_frac,
                "residual_frac": args.residual_frac,
                "lam": lam,
                "side_bits": args.side_bits,
            }
            q3 = quantize_t1_v3(weights, **common)
            dq3 = dequantize_t1_v3(q3)
            row3 = {
                "version": "v3",
                "seed": seed,
                "n": args.n,
                "group": args.group,
                "lam": lam,
                "outlier_frac": args.outlier_frac,
                "residual_frac": args.residual_frac,
                "side_bits": args.side_bits,
                "bpw_estimated": bits_per_weight_t1_v3(q3),
                "relative_error": relative_error(weights, dq3),
            }
            rows.append(row3)

            q4 = quantize_t1_v4(weights, **common)
            dq4 = dequantize_t1_v4(q4)
            row4 = {
                "version": "v4",
                "seed": seed,
                "n": args.n,
                "group": args.group,
                "lam": lam,
                "outlier_frac": args.outlier_frac,
                "residual_frac": args.residual_frac,
                "side_bits": args.side_bits,
                "bpw_estimated": bits_per_weight_t1_v4(q4),
                "relative_error": relative_error(weights, dq4),
            }
            rows.append(row4)

    columns = [
        "version", "seed", "n", "group", "lam", "outlier_frac",
        "residual_frac", "side_bits", "bpw_estimated", "relative_error",
    ]
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns)
            writer.writeheader()
            writer.writerows(rows)
        print(f"Wrote {len(rows)} rows to {args.output}")
    else:
        writer = csv.DictWriter(sys.stdout, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
