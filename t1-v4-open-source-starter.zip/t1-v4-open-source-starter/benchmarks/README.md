# Benchmarking protocol

## Preliminary measurements supplied by the author

| Estimated BPW | Relative error | Version | Provenance |
|---:|---:|:---|:---|
| 1.90 | 29.8% | V3 | Author-reported; not independently reproduced |
| 2.02 | 28.8% | V3 | Author-reported; not independently reproduced |
| 2.48 | 25.4% | V4 | Author-reported; not independently reproduced |
| 3.00 | 18.6% | V4 | Author-reported; not independently reproduced |

The test snippet shared with this repository uses 200,000 synthetic weights: 99% sampled from `N(0, 0.02²)` and 1% from `N(0, 0.2²)`, then shuffled and reshaped to `(-1, 1000)`. Record the exact settings before calling a number reproducible.

## Recommended procedure

1. Use exactly the same weight array, dtype, `group`, outlier fraction, residual fraction, and side-value format for each algorithm.
2. Sweep `lam` for both V3 and V4 to produce rate–distortion curves.
3. Compare errors at matched **measured effective BPW**. Prefer matching within a stated tolerance, and report the tolerance.
4. Run multiple fixed seeds; report mean and standard deviation (or a confidence interval).
5. Report relative error definition, MSE, number of non-zeros, estimated BPW, serialized bytes, runtime, peak memory, and machine/software details.
6. Keep outlier and residual settings equal in the main comparison. Add ablations without outliers/residuals to isolate the quantizer's contribution.
7. Include at least one real model-weight tensor and, if the intended application is neural-network inference, evaluate downstream quality/perplexity as relevant.

## Result template

Copy `benchmark_template.csv` and add one row per run. Do not fill missing measurements with estimates. Mark which values are measured and which are derived.
