# Publishing and release checklist

## 1. Review the repository

The code is in `Tiagotop333333/t1-v4-open-source`. Review these files before tagging a release.
- Confirm you have the right to redistribute all inherited V3 helper code.
- Add the real `improved.py`, `v3.py`, and `quant.py` modules under `src/ternario/` before calling the code runnable.
- Keep reported benchmarks clearly marked as preliminary until the full protocol is reproducible.

## 2. Before making a release

- Confirm you have the right to redistribute all inherited V3 helper code.
- Add the real `improved.py`, `v3.py`, and `quant.py` modules under `src/ternario/` before describing the package as runnable.
- Run the full test suite from a clean clone.
- Keep reported benchmarks clearly marked as preliminary until the full protocol is reproducible.
- Add topics such as `quantization`, `model-compression`, `sparse-quantization`, and `neural-networks` if appropriate.
- Tag a version only after the code, tests, and benchmark command work from a clean clone.
