# T1 v4 — Hierarchical Ternary Quantization

**Status: research prototype / experimental.** T1 v4 explores five reconstruction levels per group: `{-α₁, -α₂, 0, +α₂, +α₁}`, with `α₂ < α₁`. It targets a rate–distortion trade-off in which a group can represent fewer weights while retaining two non-zero magnitudes for finer reconstruction.

> **Important integration note:** the supplied `src/ternario/v4.py` still imports codec helpers from `ternario.improved` and `ternario.v3`. Those source files were not included in the material used to prepare this starter repository. Copy the relevant modules into `src/ternario/` (after checking their license and dependencies) before claiming this repository is runnable or publishing a release. See [`INTEGRATION.md`](INTEGRATION.md).

## Idea

For each group, the encoder searches a small grid of threshold multipliers (`_TAUS`) and magnitude ratios (`_BETAS`). It alternates magnitude assignment and scale updates, then chooses the configuration minimizing

`SSE + λ × 2 × nonzero_count`.

The representation stores a non-zero bitmap (one bit per padded weight), then a sign bit and a magnitude-selection bit for each non-zero weight. Two group scales are encoded using the shared V3 log-scale codec. Outliers and residual corrections are inherited from the V3 design.

## Current reported results

The following numbers were supplied by the author. They are included as **author-reported preliminary measurements**, not an independently reproduced benchmark. The rows shown do not form matched-BPW pairs, so they should not be used by themselves to claim a same-rate win.

| Estimated BPW | Reported relative error | Version |
|---:|---:|:---|
| 1.90 | 29.8% | V3 |
| 2.02 | 28.8% | V3 |
| 2.48 | 25.4% | V4 |
| 3.00 | 18.6% | V4 |

See [`benchmarks/README.md`](benchmarks/README.md) for the protocol and data needed for a reproducible comparison.

## Repository layout

```text
src/ternario/v4.py          T1 v4 encoder, decoder, and estimated-BPW function
src/ternario/               Shared V3 helper modules must be added here
 docs/algorithm.md           Algorithm and bit-accounting notes
 benchmarks/                 Preliminary results, CSV template, sweep script
 tests/                      Test plan, including an identified test correction
 INTEGRATION.md               Steps required before release
 LICENSE                      MIT License
 CITATION.cff                 Citation metadata template
```

## Before running

1. Add the original, licensed `improved.py`, `v3.py`, and `quant.py` modules under `src/ternario/`.
2. Check that their APIs match the imports in `v4.py`.
3. Create a clean environment, install NumPy, then install the project in editable mode (`pip install -e .`) once the imports are complete.
4. Port the integration tests from your working repository; use `tests/TEST_PLAN.md` as a checklist.
5. Run `python benchmarks/run_synthetic_sweep.py --seeds 0,1,2 --output benchmarks/local_sweep.csv` after integrating the helper modules.
6. Record full configuration, actual serialized size, and matched-rate results.

This starter is intentionally not presented as a self-contained, install-and-run implementation until those dependencies and tests are included.

## Scope and limitations

- The implementation is a prototype and its Python dictionary format is not a stable on-disk serialization format.
- `bits_per_weight_t1_v4()` is an estimate. Compare it with actual serialized byte counts and include metadata/header costs in reported results.
- The benchmark shown here uses a synthetic mixture of normal distributions; include real model weights and, where applicable, downstream task metrics before making broad claims.
- Runtime, memory peak, numerical stability, behavior on empty inputs, parameter validation, and cross-version decoding have not been comprehensively evaluated in this starter.

## License

The repository uses the MIT License. Confirm that all inherited helper code can legally be redistributed under that license.
